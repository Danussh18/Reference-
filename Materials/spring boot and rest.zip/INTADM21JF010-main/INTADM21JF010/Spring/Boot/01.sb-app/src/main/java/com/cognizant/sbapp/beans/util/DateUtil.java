package com.cognizant.sbapp.beans.util;

import org.springframework.stereotype.Component;

@Component
public class DateUtil {
 public DateUtil() {
	 System.out.println("**** Dateutil :: Constructor ****");
 }
}
