package co.cognizant.beans;

import org.springframework.stereotype.Component;

@Component
public class Ticket {
 public Ticket() {
	 System.out.println("**** Ticket :: Constructor ****");
 }
}
