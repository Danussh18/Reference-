package com.cognizant.sbapp.beans;

import org.springframework.stereotype.Component;

@Component
public class B {
	public B() {
		System.out.println("**** B :: Constructor ****");
	}
}
