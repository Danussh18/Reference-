package com.cognizant.sbapp.beans;

public interface Engine {
 public Integer start(); 
}
