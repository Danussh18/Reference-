package com.cognizant.library.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookControllerTest {

	@Test
	public void testGetAllBooks() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBookByBookId() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddNewBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveOrUpdateBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateAuthorName() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteBookById() {
		fail("Not yet implemented");
	}

}
