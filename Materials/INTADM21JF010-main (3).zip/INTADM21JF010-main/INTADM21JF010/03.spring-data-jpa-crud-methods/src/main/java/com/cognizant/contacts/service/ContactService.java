package com.cognizant.contacts.service;

import com.cognizant.contacts.entity.Contact;

public interface ContactService {
  public Contact saveContact(Contact contact);
  
  
}
