package com.cognizant.patterns.abstractpattern;

public abstract class Dao {
 public abstract void save();
}
