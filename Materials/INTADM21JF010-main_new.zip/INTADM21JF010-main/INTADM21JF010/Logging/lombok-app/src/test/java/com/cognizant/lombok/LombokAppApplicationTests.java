package com.cognizant.lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LombokAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
