package com.cognizant.app;

public class ReportGenerator {

	public static void main(String[] args) {
		System.out.println("---- main method starts ----");
		generateReport();
		System.out.println("---- main method ends ----");
	}

	private static void generateReport() {
		System.out.println("---- generateReport method execution starts---");
		//business logic
		System.out.println("---- generateReport method execution ended---");
	}

}
